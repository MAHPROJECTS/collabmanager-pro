def create_project():
    pass  # TODO: Add logic to create a new project

def join_project():
    pass  # TODO: Add logic to join an existing project
